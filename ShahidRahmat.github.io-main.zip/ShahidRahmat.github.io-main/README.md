# ShahidRahmat.github.io

An experiment with HTML and CSS tested on [JSFiddle](https://jsfiddle.net), an online IDE for coding with HTMl, CSS and JavaScript.

You may see the outcome of the code through [this link.](https://shahidrahmat.github.io)
